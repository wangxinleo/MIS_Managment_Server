/*!
 *  基于vue构建  
 *  copyright: wangxinleo wangxin.leo@outlook.com 
 *  time: 2020-6-12 11:14:32
 */
(window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["chunk-2d221e32"],{cbeb:function(n,t,e){"use strict";e.r(t);var a=function(){var n=this,t=n.$createElement,e=n._self._c||t;return e("div",{staticClass:"MISPCMaintain-container"},[n._v(" 正在开发，下一版本放出 ")])},c=[],i={name:"MispcMaintain",components:{},data:function(){return{}},created:function(){},mounted:function(){},methods:{}},o=i,u=e("2877"),s=Object(u["a"])(o,a,c,!1,null,null,null);t["default"]=s.exports}}]);